import axiosInstance from "../../../api/apiClient";

const BASE = "/admin/categories";

// GET /api/v1/admin/categories?page=&limit=&search=&parentCategory=
export const fetchCategories = (params = {}) =>
  axiosInstance.get(BASE, { params: { limit: 200, ...params } });

// GET /api/v1/admin/categories/:id
export const fetchCategoryById = (id) => axiosInstance.get(`${BASE}/${id}`);

// POST /api/v1/admin/categories  (multipart/form-data — image is optional)
export const createCategory = (payload) => {
  const formData = new FormData();
  Object.entries(payload).forEach(([key, value]) => {
    if (value === undefined || value === null || value === "") return;
    if (key === "image" && value instanceof File) {
      formData.append("image", value);
    } else if (Array.isArray(value) || typeof value === "object") {
      formData.append(key, JSON.stringify(value));
    } else {
      formData.append(key, value);
    }
  });
  return axiosInstance.post(BASE, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

// PUT /api/v1/admin/categories/:id
export const updateCategory = (id, payload) => {
  const formData = new FormData();
  Object.entries(payload).forEach(([key, value]) => {
    if (value === undefined || value === null || value === "") return;
    if (key === "image" && value instanceof File) {
      formData.append("image", value);
    } else if (Array.isArray(value) || typeof value === "object") {
      formData.append(key, JSON.stringify(value));
    } else {
      formData.append(key, value);
    }
  });
  return axiosInstance.put(`${BASE}/${id}`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

// PATCH /api/v1/admin/categories/:id/toggle-status
export const toggleCategoryStatus = (id) =>
  axiosInstance.patch(`${BASE}/${id}/toggle-status`);

// DELETE /api/v1/admin/categories/:id
export const deleteCategory = (id) => axiosInstance.delete(`${BASE}/${id}`);