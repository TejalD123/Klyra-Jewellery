import ComingSoon from "../components/ComingSoon";

export default function Delivery() {
  return (
    <ComingSoon
      title="Delivery"
      note="Delivery module backend planned for later — nav item is already wired and marked 'Soon' in the sidebar so it's ready to activate once the backend exists."
    />
  );
}