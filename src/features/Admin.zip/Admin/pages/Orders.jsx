import { useEffect, useState } from "react";
import Topbar from "../components/TopBar";
import StatusBadge from "../components/StatusBadge";
import { fetchAllOrders, updateOrderStatus, updatePaymentStatus } from "../services/orderService";
import "../styles/admincard.css";
import "../styles/adminbutton.css";
import "../styles/admintable.css";

const ORDER_STATUSES = ["placed", "confirmed", "processing", "shipped", "delivered", "cancelled"];
const PAYMENT_STATUSES = ["pending", "paid", "failed", "refunded", "partially_refunded"];

const currency = (n) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n || 0);

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1, total: 0 });
  const [statusFilter, setStatusFilter] = useState("");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = (page = 1) => {
    setLoading(true);
    fetchAllOrders({ page, orderStatus: statusFilter || undefined, search: search || undefined })
      .then((res) => {
        setOrders(res.data.orders);
        setPagination(res.data.pagination);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(1); }, [statusFilter]);

  const handleStatusChange = async (id, newStatus) => {
    try {
      await updateOrderStatus(id, newStatus);
      load(pagination.page);
    } catch (err) {
      alert(err.message);
    }
  };

  const handlePaymentChange = async (id, newStatus) => {
    try {
      await updatePaymentStatus(id, newStatus);
      load(pagination.page);
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      <Topbar title="Orders" subtitle={`${pagination.total} total`} />

      <div className="flex gap-3 items-center">
        <select
          className="admin-btn admin-btn-ghost"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="">All statuses</option>
          {ORDER_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <div className="admin-field" style={{ maxWidth: 260 }}>
          <input
            placeholder="Search order number…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && load(1)}
          />
        </div>
      </div>

      <div className="admin-card overflow-hidden">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Order #</th>
              <th>Customer</th>
              <th>Items</th>
              <th>Amount</th>
              <th>Order Status</th>
              <th>Payment</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} className="text-center py-8">Loading…</td></tr>
            ) : error ? (
              <tr><td colSpan={7} className="text-center py-8" style={{ color: "var(--admin-danger)" }}>{error}</td></tr>
            ) : orders.length === 0 ? (
              <tr><td colSpan={7} className="text-center py-8">Kahi order sapadla nahi.</td></tr>
            ) : (
              orders.map((order) => (
                <tr key={order._id}>
                  <td className="font-medium">{order.orderNumber}</td>
                  <td>
                    <div>{order.user?.username || "—"}</div>
                    <div className="text-xs" style={{ color: "var(--admin-text-muted)" }}>
                      {order.user?.email || order.user?.phone}
                    </div>
                  </td>
                  <td className="text-sm">{order.items?.length} item(s)</td>
                  <td>{currency(order.pricing?.totalAmount)}</td>
                  <td>
                    <select
                      value={order.orderStatus}
                      disabled={order.orderStatus === "cancelled" || order.orderStatus === "delivered"}
                      onChange={(e) => handleStatusChange(order._id, e.target.value)}
                      className="text-sm"
                      style={{ background: "transparent", border: "none" }}
                    >
                      {ORDER_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                    <div><StatusBadge status={order.orderStatus} /></div>
                  </td>
                  <td>
                    <select
                      value={order.paymentStatus}
                      onChange={(e) => handlePaymentChange(order._id, e.target.value)}
                      className="text-sm"
                      style={{ background: "transparent", border: "none" }}
                    >
                      {PAYMENT_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                    <div><StatusBadge status={order.paymentStatus} kind="payment" /></div>
                  </td>
                  <td className="text-sm" style={{ color: "var(--admin-text-muted)" }}>
                    {new Date(order.createdAt).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>

        {pagination.totalPages > 1 && (
          <div className="flex items-center justify-between p-4 text-sm" style={{ color: "var(--admin-text-muted)" }}>
            <span>Page {pagination.page} of {pagination.totalPages}</span>
            <div className="flex gap-2">
              <button className="admin-btn admin-btn-ghost" disabled={pagination.page <= 1} onClick={() => load(pagination.page - 1)}>Previous</button>
              <button className="admin-btn admin-btn-ghost" disabled={pagination.page >= pagination.totalPages} onClick={() => load(pagination.page + 1)}>Next</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}