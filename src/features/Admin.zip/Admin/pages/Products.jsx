import { useEffect, useState } from "react";
import Topbar from "../components/TopBar";
import {
  fetchProducts,
  createProduct,
  updateProductStock,
  toggleProductFeatured,
  toggleProductStatus,
  deleteProduct,
} from "../services/productService";
import { fetchCategories } from "../services/categoryService";

import "../styles/admincard.css";
import "../styles/adminbutton.css";
import "../styles/admintable.css";
import "../styles/adminbadge.css";
import "../styles/adminform.css";

const METAL_TYPES = ["18K Yellow Gold", "22K Gold", "Sterling Silver", "Platinum", "Rose Gold"];
const STONE_TYPES = ["VVS1 Natural Diamond", "Pearl", "Kundan", "Ruby", "Emerald", "None"];
const DEFAULT_SIZES = ["48", "50", "52", "54", "56"];

const slugify = (str = "") =>
  str.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

const IconInfo = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8h.01" strokeLinecap="round" />
  </svg>
);
const IconSpec = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <rect x="3" y="4" width="7" height="7" rx="1" /><rect x="14" y="4" width="7" height="7" rx="1" />
    <rect x="3" y="15" width="7" height="5" rx="1" /><rect x="14" y="15" width="7" height="5" rx="1" />
  </svg>
);
const IconPricing = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <circle cx="12" cy="12" r="9" />
    <path d="M9 15c0 1.1 1.3 2 3 2s3-.9 3-2-1.3-1.7-3-2-3-.9-3-2 1.3-2 3-2 3 .9 3 2" strokeLinecap="round" />
  </svg>
);
const IconMedia = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <rect x="3" y="4" width="18" height="16" rx="2" /><circle cx="8.5" cy="9.5" r="1.5" />
    <path d="M21 16l-5-5-4 4-3-3-5 5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
const IconUpload = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
    <path d="M12 16V4M8 8l4-4 4 4" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M4 16v3a2 2 0 002 2h12a2 2 0 002-2v-3" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
const IconPlus = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M12 5v14M5 12h14" strokeLinecap="round" />
  </svg>
);

const emptyForm = {
  name: "",
  slug: "",
  sku: "",
  description: "",
  category: "",
  metalType: METAL_TYPES[0],
  weight: "",
  stoneType: STONE_TYPES[0],
  sizes: [],
  basePrice: "",
  makingCharges: 0,
  discount: 0,
  images: [],
  stock: 0,
  isActive: true,
  isFeatured: false,
  allowCustomEngraving: false,
  isNewArrival: false,
  collection: "",
};

const currency = (n) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n || 0);

export default function Products() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1, total: 0 });
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [slugTouched, setSlugTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");

  const loadProducts = (page = 1, q = search) => {
    setLoading(true);
    fetchProducts({ page, search: q || undefined })
      .then((res) => {
        setProducts(res.data.products);
        setPagination(res.data.pagination);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadProducts(1, "");
    fetchCategories().then((res) => setCategories(res.data.categories)).catch(() => {});
  }, []);

  const handleNameChange = (value) => {
    setForm((f) => ({ ...f, name: value, slug: slugTouched ? f.slug : slugify(value) }));
  };

  const toggleSize = (size) => {
    setForm((f) => ({
      ...f,
      sizes: f.sizes.includes(size) ? f.sizes.filter((s) => s !== size) : [...f.sizes, size],
    }));
  };

  const addCustomSize = () => {
    const value = window.prompt("Enter size:");
    if (value) toggleSize(value);
  };

  const subtotal = (Number(form.basePrice) || 0) + (Number(form.makingCharges) || 0);
  const estimatedPrice = subtotal - (subtotal * (Number(form.discount) || 0)) / 100;

  const resetForm = () => {
    setForm(emptyForm);
    setSlugTouched(false);
    setFormError("");
    setShowForm(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError("");
    if (!form.name || !form.category || !form.weight || !form.basePrice) {
      setFormError("Name, category, weight ani base price required ahet");
      return;
    }
    setSaving(true);
    try {
      const { images, sizes, ...rest } = form;
      await createProduct({ ...rest, sizeOptions: sizes }, images);
      resetForm();
      loadProducts(1, "");
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleStockUpdate = async (id, currentStock) => {
    const value = window.prompt("Naya stock quantity taak:", currentStock);
    if (value === null || isNaN(Number(value))) return;
    await updateProductStock(id, "set", Number(value));
    loadProducts(pagination.page);
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`"${name}" delete karायचi?`)) return;
    try {
      await deleteProduct(id);
      loadProducts(pagination.page);
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      <Topbar
        title="Products"
        subtitle={`${pagination.total} total`}
        actions={
          <button className="admin-btn admin-btn-primary" onClick={() => setShowForm((s) => !s)}>
            {showForm ? "Cancel" : "+ Create Product"}
          </button>
        }
      />

      {showForm && (
        <form onSubmit={handleSubmit} className="admin-form-container">
          {formError && <div className="admin-form-error">{formError}</div>}

          <div className="admin-form-columns">
            {/* ---- LEFT COLUMN ---- */}
            <div className="admin-form-col">
              {/* ---- General Information ---- */}
              <section className="admin-form-section">
                <div className="admin-form-section__header">
                  <IconInfo />
                  <span className="admin-form-section__title">General Information</span>
                </div>
                <div className="admin-form-section__body admin-form-grid">
                  <div className="admin-field admin-form-grid--full">
                    <label>Product Name</label>
                    <input
                      placeholder="e.g. Celestial Diamond Halo Ring"
                      value={form.name}
                      onChange={(e) => handleNameChange(e.target.value)}
                    />
                  </div>
                  <div className="admin-field">
                    <label>Slug (URL Key)</label>
                    <input
                      className="is-slug"
                      placeholder="celestial-diamond-halo-ring"
                      value={form.slug}
                      onChange={(e) => { setSlugTouched(true); setForm((f) => ({ ...f, slug: slugify(e.target.value) })); }}
                    />
                  </div>
                  <div className="admin-field">
                    <label>SKU Code</label>
                    <input
                      placeholder="LX-DR-0021"
                      value={form.sku}
                      onChange={(e) => setForm((f) => ({ ...f, sku: e.target.value }))}
                    />
                  </div>
                  <div className="admin-field admin-form-grid--full">
                    <label>Category</label>
                    <select value={form.category} onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}>
                      <option value="">Select category</option>
                      {categories.map((c) => (
                        <option key={c._id} value={c._id}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="admin-field admin-form-grid--full">
                    <label>Description</label>
                    <textarea
                      rows={3}
                      placeholder="Describe the craftsmanship, heritage, and unique features…"
                      value={form.description}
                      onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                    />
                  </div>
                </div>
              </section>

              {/* ---- Product Specifications ---- */}
              <section className="admin-form-section">
                <div className="admin-form-section__header">
                  <IconSpec />
                  <span className="admin-form-section__title">Product Specifications</span>
                </div>
                <div className="admin-form-section__body admin-form-grid">
                  <div className="admin-field">
                    <label>Metal Type</label>
                    <select value={form.metalType} onChange={(e) => setForm((f) => ({ ...f, metalType: e.target.value }))}>
                      {METAL_TYPES.map((m) => <option key={m} value={m}>{m}</option>)}
                    </select>
                  </div>
                  <div className="admin-field">
                    <label>Metal Weight (g)</label>
                    <input
                      type="number" step="0.01"
                      value={form.weight}
                      onChange={(e) => setForm((f) => ({ ...f, weight: e.target.value }))}
                    />
                  </div>
                  <div className="admin-field admin-form-grid--full">
                    <label>Stone Type</label>
                    <select value={form.stoneType} onChange={(e) => setForm((f) => ({ ...f, stoneType: e.target.value }))}>
                      {STONE_TYPES.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                  </div>
                  <div className="admin-field admin-form-grid--full">
                    <label>Available Sizes</label>
                    <div className="admin-chip-row">
                      {[...new Set([...DEFAULT_SIZES, ...form.sizes])].map((size) => (
                        <button
                          type="button"
                          key={size}
                          className={`admin-chip ${form.sizes.includes(size) ? "is-selected" : ""}`}
                          onClick={() => toggleSize(size)}
                        >
                          {size}
                        </button>
                      ))}
                      <button type="button" className="admin-chip-add" onClick={addCustomSize} aria-label="Add size">
                        <IconPlus />
                      </button>
                    </div>
                  </div>
                </div>
              </section>

              {/* ---- Pricing & Valuation ---- */}
              <section className="admin-form-section">
                <div className="admin-form-section__header">
                  <IconPricing />
                  <span className="admin-form-section__title">Pricing &amp; Valuation</span>
                </div>
                <div className="admin-form-section__body admin-form-grid">
                  <div className="admin-field">
                    <label>Base Price (₹)</label>
                    <input
                      type="number"
                      value={form.basePrice}
                      onChange={(e) => setForm((f) => ({ ...f, basePrice: e.target.value }))}
                    />
                  </div>
                  <div className="admin-field">
                    <label>Making Charges (₹)</label>
                    <input
                      type="number"
                      value={form.makingCharges}
                      onChange={(e) => setForm((f) => ({ ...f, makingCharges: e.target.value }))}
                    />
                  </div>
                  <div className="admin-field admin-form-grid--full">
                    <label>Discount (%)</label>
                    <input
                      type="number"
                      value={form.discount}
                      onChange={(e) => setForm((f) => ({ ...f, discount: e.target.value }))}
                    />
                  </div>
                  <div className="admin-form-grid--full admin-computed-banner">
                    <span className="admin-computed-banner__label">Estimated Retail Price</span>
                    <span className="admin-computed-banner__value">{currency(estimatedPrice)}</span>
                  </div>
                </div>
              </section>
            </div>

            {/* ---- RIGHT COLUMN ---- */}
            <div className="admin-form-col">
              {/* ---- Product Media ---- */}
              <section className="admin-form-section">
                <div className="admin-form-section__header">
                  <IconMedia />
                  <span className="admin-form-section__title">Product Media</span>
                </div>
                <div className="admin-form-section__body">
                  <label className="admin-dropzone">
                    <IconUpload />
                    <span className="admin-dropzone__title">Primary Asset</span>
                    <span className="admin-dropzone__hint">Drag and drop or click to upload (up to 8 images)</span>
                    <input
                      type="file" accept="image/*" multiple
                      onChange={(e) => setForm((f) => ({ ...f, images: Array.from(e.target.files).slice(0, 8) }))}
                    />
                  </label>
                  {form.images.length > 0 && (
                    <div className="admin-thumb-row">
                      {form.images.map((file, i) => (
                        <div key={i} className="admin-thumb">
                          <img src={URL.createObjectURL(file)} alt={`upload-${i}`} />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </section>

              {/* ---- Availability & Logistics ---- */}
              <section className="admin-form-section">
                <div className="admin-form-section__header">
                  <IconSpec />
                  <span className="admin-form-section__title">Availability &amp; Logistics</span>
                </div>
                <div className="admin-form-section__body admin-form-grid">
                  <div className="admin-field admin-form-grid--full">
                    <label>Stock Level</label>
                    <input
                      type="number"
                      value={form.stock}
                      onChange={(e) => setForm((f) => ({ ...f, stock: e.target.value }))}
                    />
                  </div>
                  <div className="admin-form-grid--full admin-toggle-row">
                    <span className="admin-toggle-row__label">Live on Storefront</span>
                    <button
                      type="button"
                      className={`admin-toggle ${form.isActive ? "is-on" : ""}`}
                      onClick={() => setForm((f) => ({ ...f, isActive: !f.isActive }))}
                    >
                      <span className="admin-toggle__dot" />
                    </button>
                  </div>
                </div>
              </section>

              {/* ---- Marketing Flags ---- */}
              <section className="admin-form-section">
                <div className="admin-form-section__header">
                  <IconInfo />
                  <span className="admin-form-section__title">Marketing Flags</span>
                </div>
                <div className="admin-form-section__body">
                  <div className="admin-checkbox-list">
                    <label className="admin-checkbox-row">
                      <input
                        type="checkbox"
                        checked={form.isFeatured}
                        onChange={(e) => setForm((f) => ({ ...f, isFeatured: e.target.checked }))}
                      />
                      Featured Product
                    </label>
                    <label className="admin-checkbox-row">
                      <input
                        type="checkbox"
                        checked={form.allowCustomEngraving}
                        onChange={(e) => setForm((f) => ({ ...f, allowCustomEngraving: e.target.checked }))}
                      />
                      Allow Custom Engraving
                    </label>
                    <label className="admin-checkbox-row">
                      <input
                        type="checkbox"
                        checked={form.isNewArrival}
                        onChange={(e) => setForm((f) => ({ ...f, isNewArrival: e.target.checked }))}
                      />
                      New Arrival
                    </label>
                  </div>
                </div>
              </section>
            </div>
          </div>

          <div className="admin-form-footer">
            <button type="button" className="admin-btn admin-btn-ghost" onClick={resetForm}>
              Discard
            </button>
            <button type="submit" disabled={saving} className="admin-btn admin-btn-primary">
              {saving ? "Saving…" : "Create Product"}
            </button>
          </div>
        </form>
      )}

      <div className="admin-field" style={{ maxWidth: 320 }}>
        <input
          placeholder="Search by name / SKU…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && loadProducts(1, search)}
        />
      </div>

      <div className="admin-card overflow-hidden">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>SKU</th>
              <th>Category</th>
              <th>Metal</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={8} className="text-center py-8">Loading…</td></tr>
            ) : error ? (
              <tr><td colSpan={8} className="text-center py-8" style={{ color: "var(--admin-danger)" }}>{error}</td></tr>
            ) : products.length === 0 ? (
              <tr><td colSpan={8} className="text-center py-8">Kahi product sapadla nahi.</td></tr>
            ) : (
              products.map((p) => (
                <tr key={p._id}>
                  <td className="font-medium">
                    {p.name}
                    {p.isFeatured && <span className="admin-badge admin-badge-warning ml-2">featured</span>}
                  </td>
                  <td className="text-sm" style={{ color: "var(--admin-text-muted)" }}>{p.sku}</td>
                  <td className="text-sm">{p.category?.name || "—"}</td>
                  <td className="text-sm capitalize">{p.metalType}</td>
                  <td>{currency(p.finalPrice)}</td>
                  <td>
                    <button
                      className={`admin-badge ${p.stock <= 5 ? "admin-badge-danger" : "admin-badge-neutral"}`}
                      onClick={() => handleStockUpdate(p._id, p.stock)}
                      title="Click to update stock"
                    >
                      {p.stock}
                    </button>
                  </td>
                  <td>
                    <span className={`admin-badge ${p.isActive ? "admin-badge-success" : "admin-badge-neutral"}`}>
                      {p.isActive ? "active" : "inactive"}
                    </span>
                  </td>
                  <td>
                    <div className="flex gap-2">
                      <button
                        className="admin-btn admin-btn-ghost"
                        onClick={() => toggleProductStatus(p._id).then(() => loadProducts(pagination.page))}
                      >
                        {p.isActive ? "Deactivate" : "Activate"}
                      </button>
                      <button
                        className="admin-btn admin-btn-ghost"
                        onClick={() => toggleProductFeatured(p._id).then(() => loadProducts(pagination.page))}
                      >
                        {p.isFeatured ? "Unfeature" : "Feature"}
                      </button>
                      <button className="admin-btn admin-btn-danger" onClick={() => handleDelete(p._id, p.name)}>
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>

        {pagination.totalPages > 1 && (
          <div className="flex items-center justify-between p-4 text-sm" style={{ color: "var(--admin-text-muted)" }}>
            <span>Page {pagination.page} of {pagination.totalPages}</span>
            <div className="flex gap-2">
              <button
                className="admin-btn admin-btn-ghost"
                disabled={pagination.page <= 1}
                onClick={() => loadProducts(pagination.page - 1)}
              >
                Previous
              </button>
              <button
                className="admin-btn admin-btn-ghost"
                disabled={pagination.page >= pagination.totalPages}
                onClick={() => loadProducts(pagination.page + 1)}
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}