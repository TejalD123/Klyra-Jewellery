import { useEffect, useState } from "react";
import Topbar from "../components/TopBar";
import StatCard from "../components/StatCard";
import StatusBadge from "../components/StatusBadge";
import { fetchDashboardStats } from "../services/admin.api";
import "../styles/admincard.css";

import "../styles/admintable.css";

const currency = (n) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n || 0);

const STATUS_ORDER = ["placed", "confirmed", "processing", "shipped", "delivered", "cancelled"];

export default function DashBoardPage() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let mounted = true;
    fetchDashboardStats()
      .then((res) => {
        // response already unwrapped by adminApi interceptor -> ApiResponse.data
        if (mounted) setStats(res.data);
      })
      .catch((err) => mounted && setError(err.message))
      .finally(() => mounted && setLoading(false));
    return () => {
      mounted = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="space-y-6">
        <Topbar title="Dashboard" subtitle="Loading today's numbers…" />
        <div className="grid grid-cols-4 gap-4">
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="admin-card p-5 h-24 animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="space-y-4">
        <Topbar title="Dashboard" />
        <div className="admin-card p-6" style={{ borderColor: "var(--admin-danger)" }}>
          <p style={{ color: "var(--admin-danger)" }}>
            Dashboard load nahi jhala: {error}
          </p>
          <p className="text-xs mt-2" style={{ color: "var(--admin-text-muted)" }}>
            Note: `getDashboardStats` is defined in admin.controller.js but I didn't see a matching
            route (e.g. <code>GET /api/admin/dashboard</code>) in admin.routes.js — confirm the exact
            path once you wire it, or share the updated route file.
          </p>
        </div>
      </div>
    );
  }

  const maxStatusCount = Math.max(1, ...STATUS_ORDER.map((s) => stats.ordersByStatus?.[s] || 0));

  return (
    <div className="space-y-6">
      <Topbar title="Dashboard" subtitle="Store performance at a glance" />

      <div className="grid grid-cols-4 gap-4">
        <StatCard label="Total Users" value={stats.totalUsers} />
        <StatCard label="Total Products" value={stats.totalProducts} hint={`${stats.totalCategories} categories`} />
        <StatCard label="Total Orders" value={stats.totalOrders} />
        <StatCard label="Total Revenue" value={currency(stats.totalRevenue)} tone="success" />
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Orders by status — plain CSS bars, no chart dependency */}
        <div className="admin-card p-5 col-span-2">
          <h3 className="text-sm font-semibold mb-4" style={{ color: "var(--admin-text-muted)" }}>
            Orders by Status
          </h3>
          <div className="space-y-3">
            {STATUS_ORDER.map((status) => {
              const count = stats.ordersByStatus?.[status] || 0;
              const pct = Math.round((count / maxStatusCount) * 100);
              return (
                <div key={status} className="flex items-center gap-3">
                  <div className="w-24 shrink-0">
                    <StatusBadge status={status} />
                  </div>
                  <div className="flex-1 h-2 rounded-full" style={{ background: "var(--admin-cream-dim)" }}>
                    <div
                      className="h-2 rounded-full transition-all duration-500"
                      style={{ width: `${pct}%`, background: "var(--admin-gold)" }}
                    />
                  </div>
                  <span className="w-8 text-right text-sm tabular-nums">{count}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Low stock */}
        <div className="admin-card p-5">
          <h3 className="text-sm font-semibold mb-4" style={{ color: "var(--admin-text-muted)" }}>
            Low Stock Alert
          </h3>
          {stats.lowStockProducts?.length ? (
            <ul className="space-y-2.5">
              {stats.lowStockProducts.map((p) => (
                <li key={p._id} className="flex items-center justify-between text-sm">
                  <span className="truncate pr-2">{p.name}</span>
                  <span className="admin-badge admin-badge-danger">{p.stock} left</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm" style={{ color: "var(--admin-text-muted)" }}>
              Sarva products sufficiently stocked ahet.
            </p>
          )}
        </div>
      </div>

      {/* Recent orders */}
      <div className="admin-card overflow-hidden">
        <div className="p-5 pb-0">
          <h3 className="text-sm font-semibold" style={{ color: "var(--admin-text-muted)" }}>
            Recent Orders
          </h3>
        </div>
        <table className="admin-table mt-3">
          <thead>
            <tr>
              <th>Order #</th>
              <th>Customer</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {stats.recentOrders?.length ? (
              stats.recentOrders.map((order) => (
                <tr key={order._id}>
                  <td className="font-medium">{order.orderNumber}</td>
                  <td>
                    <div>{order.user?.username || "—"}</div>
                    <div className="text-xs" style={{ color: "var(--admin-text-muted)" }}>
                      {order.user?.email || order.user?.phone}
                    </div>
                  </td>
                  <td>{currency(order.pricing?.totalAmount)}</td>
                  <td>
                    <StatusBadge status={order.orderStatus} />
                  </td>
                  <td className="text-sm" style={{ color: "var(--admin-text-muted)" }}>
                    {new Date(order.createdAt).toLocaleDateString("en-IN", {
                      day: "2-digit",
                      month: "short",
                    })}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} className="text-center py-8" style={{ color: "var(--admin-text-muted)" }}>
                  Ajun koni order kela nahi.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}