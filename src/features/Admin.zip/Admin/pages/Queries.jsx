import ComingSoon from "../components/ComingSoon";

export default function Queries() {
  return (
    <ComingSoon
      title="Queries"
      note="No customer-query backend exists yet — this needs a fresh Query/Enquiry model (name, email, subject, message, status) + controller/routes. Confirm the fields you want captured and I'll build it end-to-end."
    />
  );
}