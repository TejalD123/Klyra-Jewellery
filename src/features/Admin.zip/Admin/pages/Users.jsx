import ComingSoon from "../components/ComingSoon";

export default function Users() {
  return (
    <ComingSoon
      title="Users"
      note="User analytics (total users, today's signups, activity) need user.controller.js and user.model.js — share those and I'll wire the list + stats here, same pattern as Categories/Products."
    />
  );
}