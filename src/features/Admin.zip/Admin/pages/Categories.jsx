import { useEffect, useState } from "react";
import Topbar from "../components/TopBar";
import {
  fetchCategories,
  createCategory,
  toggleCategoryStatus,
  deleteCategory,
} from "../services/Categoryservice";

import "../styles/admincard.css";
import "../styles/adminbutton.css";
import "../styles/admintable.css";
import "../styles/adminbadge.css";
import "../styles/adminform.css";

const METAL_OPTIONS = ["18K Gold", "Platinum", "Sterling Silver", "Rose Gold"];

const slugify = (str = "") =>
  str.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");

const IconInfo = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8h.01" strokeLinecap="round" />
  </svg>
);
const IconGem = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M6 3h12l3 5-9 13L3 8l3-5z" strokeLinejoin="round" />
    <path d="M3 8h18M8.5 3 12 8l3.5-5" strokeLinejoin="round" />
  </svg>
);
const IconImage = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <rect x="3" y="4" width="18" height="16" rx="2" />
    <circle cx="8.5" cy="9.5" r="1.5" />
    <path d="M21 16l-5-5-4 4-3-3-5 5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
const IconLayers = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M12 3l9 5-9 5-9-5 9-5z" strokeLinejoin="round" />
    <path d="M3 13l9 5 9-5" strokeLinejoin="round" />
  </svg>
);
const IconUpload = () => (
  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
    <path d="M12 16V4M8 8l4-4 4 4" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M4 16v3a2 2 0 002 2h12a2 2 0 002-2v-3" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const emptyForm = {
  name: "",
  slug: "",
  description: "",
  metalTypes: [],
  attributes: [{ name: "", value: "" }],
  image: null,
  parentCategory: "",
  displayOrder: 0,
  isActive: true,
};

export default function Categories() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [slugTouched, setSlugTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");

  const loadCategories = () => {
    setLoading(true);
    fetchCategories()
      .then((res) => setCategories(res.data.categories))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  };

  useEffect(loadCategories, []);

  const subcategoryCount = (categoryId) =>
    categories.filter((c) => {
      const parentId = c.parentCategory?._id || c.parentCategory;
      return String(parentId) === String(categoryId);
    }).length;

  const topLevelCategories = categories.filter((c) => !c.parentCategory);

  const handleNameChange = (value) => {
    setForm((f) => ({ ...f, name: value, slug: slugTouched ? f.slug : slugify(value) }));
  };

  const toggleMetal = (metal) => {
    setForm((f) => ({
      ...f,
      metalTypes: f.metalTypes.includes(metal)
        ? f.metalTypes.filter((m) => m !== metal)
        : [...f.metalTypes, metal],
    }));
  };

  const updateAttribute = (idx, key, value) => {
    setForm((f) => {
      const attrs = [...f.attributes];
      attrs[idx] = { ...attrs[idx], [key]: value };
      return { ...f, attributes: attrs };
    });
  };

  const addAttribute = () => {
    setForm((f) => ({ ...f, attributes: [...f.attributes, { name: "", value: "" }] }));
  };

  const resetForm = () => {
    setForm(emptyForm);
    setSlugTouched(false);
    setFormError("");
    setShowForm(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFormError("");
    if (!form.name.trim()) {
      setFormError("Category name required ahe");
      return;
    }
    setSaving(true);
    try {
      await createCategory({
        name: form.name,
        description: form.description,
        parentCategory: form.parentCategory || null,
        metalTypes: form.metalTypes.map((m) => m.toLowerCase()),
        displayOrder: Number(form.displayOrder) || 0,
        isActive: form.isActive,
        image: form.image,
      });
      resetForm();
      loadCategories();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleToggle = async (id) => {
    await toggleCategoryStatus(id);
    loadCategories();
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`"${name}" delete karायचi? Ha action undo hoत nahi.`)) return;
    try {
      await deleteCategory(id);
      loadCategories();
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6">
      <Topbar
        title="Categories"
        subtitle={`${categories.length} total`}
        actions={
          <button className="admin-btn admin-btn-primary" onClick={() => setShowForm((s) => !s)}>
            {showForm ? "Cancel" : "+ Create Category"}
          </button>
        }
      />

      {showForm && (
        <form onSubmit={handleSubmit} className="admin-form-container">
          {formError && <div className="admin-form-error">{formError}</div>}

          <div className="admin-form-columns">
            {/* ---- LEFT COLUMN ---- */}
            <div className="admin-form-col">
              {/* ---- General Information ---- */}
              <section className="admin-form-section">
                <div className="admin-form-section__header">
                  <IconInfo />
                  <span className="admin-form-section__title">General Information</span>
                </div>
                <div className="admin-form-section__body admin-form-grid">
                  <div className="admin-field">
                    <label>Category Name</label>
                    <input
                      placeholder="e.g. Engagement Rings"
                      value={form.name}
                      onChange={(e) => handleNameChange(e.target.value)}
                    />
                  </div>
                  <div className="admin-field">
                    <label>URL Slug</label>
                    <input
                      className="is-slug"
                      placeholder="engagement-rings"
                      value={form.slug}
                      onChange={(e) => {
                        setSlugTouched(true);
                        setForm((f) => ({ ...f, slug: slugify(e.target.value) }));
                      }}
                    />
                  </div>
                  <div className="admin-field admin-form-grid--full">
                    <label>Description</label>
                    <textarea
                      rows={3}
                      placeholder="Briefly describe the collection's focus and heritage…"
                      value={form.description}
                      onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
                    />
                  </div>
                </div>
              </section>

              {/* ---- Luxury Attributes ---- */}
              <section className="admin-form-section">
                <div className="admin-form-section__header">
                  <IconGem />
                  <span className="admin-form-section__title">Luxury Attributes</span>
                </div>
                <div className="admin-form-section__body">
                  <div className="admin-field" style={{ marginBottom: "1.25rem" }}>
                    <label>Metal Types</label>
                    <div className="admin-form-grid">
                      {METAL_OPTIONS.map((metal) => (
                        <label
                          key={metal}
                          className={`admin-radio-card ${form.metalTypes.includes(metal) ? "is-selected" : ""}`}
                        >
                          <input
                            type="checkbox"
                            checked={form.metalTypes.includes(metal)}
                            onChange={() => toggleMetal(metal)}
                          />
                          {metal}
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="admin-field">
                    <label>Category Attributes</label>
                    {form.attributes.map((attr, idx) => (
                      <div key={idx} className="admin-form-grid" style={{ marginBottom: "0.6rem" }}>
                        <input
                          placeholder="Attribute Name (e.g. Carat Fit)"
                          value={attr.name}
                          onChange={(e) => updateAttribute(idx, "name", e.target.value)}
                        />
                        <input
                          placeholder="Default Value"
                          value={attr.value}
                          onChange={(e) => updateAttribute(idx, "value", e.target.value)}
                        />
                      </div>
                    ))}
                    <button type="button" className="admin-btn admin-btn-ghost" onClick={addAttribute}>
                      + Add Another Attribute
                    </button>
                  </div>
                </div>
              </section>
            </div>

            {/* ---- RIGHT COLUMN ---- */}
            <div className="admin-form-col">
              {/* ---- Hero Image ---- */}
              <section className="admin-form-section">
                <div className="admin-form-section__header">
                  <IconImage />
                  <span className="admin-form-section__title">Hero Image</span>
                </div>
                <div className="admin-form-section__body">
                  <label className="admin-dropzone">
                    <IconUpload />
                    <span className="admin-dropzone__title">Drag &amp; drop or click</span>
                    <span className="admin-dropzone__hint">PNG, JPG up to 10MB</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => setForm((f) => ({ ...f, image: e.target.files[0] }))}
                    />
                  </label>
                </div>
              </section>

              {/* ---- Hierarchy & Status ---- */}
              <section className="admin-form-section">
                <div className="admin-form-section__header">
                  <IconLayers />
                  <span className="admin-form-section__title">Hierarchy &amp; Status</span>
                </div>
                <div className="admin-form-section__body admin-form-grid">
                  <div className="admin-field admin-form-grid--full">
                    <label>Parent Category</label>
                    <select
                      value={form.parentCategory}
                      onChange={(e) => setForm((f) => ({ ...f, parentCategory: e.target.value }))}
                    >
                      <option value="">None (Root Category)</option>
                      {topLevelCategories.map((c) => (
                        <option key={c._id} value={c._id}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="admin-field admin-form-grid--full">
                    <label>Display Order</label>
                    <input
                      type="number"
                      value={form.displayOrder}
                      onChange={(e) => setForm((f) => ({ ...f, displayOrder: e.target.value }))}
                    />
                  </div>
                  <div className="admin-form-grid--full admin-toggle-row">
                    <div>
                      <p className="admin-toggle-row__label">Is Active</p>
                      <p className="admin-toggle-row__hint">Visible on storefront</p>
                    </div>
                    <button
                      type="button"
                      className={`admin-toggle ${form.isActive ? "is-on" : ""}`}
                      onClick={() => setForm((f) => ({ ...f, isActive: !f.isActive }))}
                    >
                      <span className="admin-toggle__dot" />
                    </button>
                  </div>
                </div>
              </section>
            </div>
          </div>

          <div className="admin-form-footer">
            <button type="button" className="admin-btn admin-btn-ghost" onClick={resetForm}>
              Discard Changes
            </button>
            <button type="submit" disabled={saving} className="admin-btn admin-btn-primary">
              {saving ? "Creating…" : "Create Category"}
            </button>
          </div>
        </form>
      )}

      <div className="admin-card overflow-hidden">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Parent</th>
              <th>Subcategories</th>
              <th>Metal Types</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={6} className="text-center py-8">Loading…</td></tr>
            ) : error ? (
              <tr><td colSpan={6} className="text-center py-8" style={{ color: "var(--admin-danger)" }}>{error}</td></tr>
            ) : categories.length === 0 ? (
              <tr><td colSpan={6} className="text-center py-8">Ajun kahi category nahi. Vartun create kar.</td></tr>
            ) : (
              categories.map((cat) => (
                <tr key={cat._id}>
                  <td className="font-medium">{cat.name}</td>
                  <td style={{ color: "var(--admin-text-muted)" }}>
                    {cat.parentCategory?.name || "— top level —"}
                  </td>
                  <td>
                    <span className="admin-badge admin-badge-info">{subcategoryCount(cat._id)}</span>
                  </td>
                  <td className="text-sm" style={{ color: "var(--admin-text-muted)" }}>
                    {cat.metalTypes?.join(", ") || "—"}
                  </td>
                  <td>
                    <span className={`admin-badge ${cat.isActive ? "admin-badge-success" : "admin-badge-neutral"}`}>
                      {cat.isActive ? "active" : "inactive"}
                    </span>
                  </td>
                  <td>
                    <div className="flex gap-2">
                      <button className="admin-btn admin-btn-ghost" onClick={() => handleToggle(cat._id)}>
                        {cat.isActive ? "Deactivate" : "Activate"}
                      </button>
                      <button className="admin-btn admin-btn-danger" onClick={() => handleDelete(cat._id, cat.name)}>
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}